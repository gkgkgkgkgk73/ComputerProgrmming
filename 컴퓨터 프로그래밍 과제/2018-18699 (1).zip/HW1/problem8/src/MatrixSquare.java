public class MatrixSquare {
    public static void printSquaredMatrix(int[][] matrix) {
        // DO NOT change the skeleton code.
        // You can add codes anywhere you want.

        printMatrix(calculator(matrix));

    }

    public static int[][] calculator(int[][] matrix) {

        int[][] outputMatrix = new int[matrix.length][matrix[0].length];

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                int sum = 0;
                for (int k = 0; k < matrix.length; k++) {
                    sum += matrix[i][k] * matrix[k][j];
                }
                outputMatrix[i][j] = sum;
            }
        }
        return outputMatrix;
    }

    public static void printMatrix(int[][] matrix){
        for(int i=0;i<matrix.length;i++){
            for(int j=0;j<matrix[0].length-1;j++){
                System.out.print(matrix[i][j]+" ");
            }
            if(i==matrix.length-1){System.out.print(matrix[i][matrix.length-1]);}
            else {System.out.println(matrix[i][matrix.length-1]);}
        }
    }
}
