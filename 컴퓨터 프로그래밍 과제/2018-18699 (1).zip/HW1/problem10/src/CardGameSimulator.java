public class CardGameSimulator {
	private static final Player[] players = new Player[2];

	public static void simulateCardGame(String inputA, String inputB) {
		// DO NOT change the skeleton code.
		// You can add codes anywhere you want.

		players[0] = new Player();
		players[1] = new Player();

		players[0].setName("A");
		players[1].setName("B");

		String[] cardA = inputA.split("\\s");
		String[] cardB = inputB.split("\\s");

		Card[] cardsA = new Card[10];
		Card[] cardsB = new Card[10];

		int largestNumCard = 0;
		int maxNum = 0;
		for(int i=0;i<10;i++){
			if(maxNum<Integer.parseInt(cardA[i].charAt(0)+"")){
				maxNum = Integer.parseInt(cardA[i].charAt(0)+"");
				largestNumCard = i;
			}else if(maxNum==Integer.parseInt(cardA[i].charAt(0)+"")){
				if(cardsA[largestNumCard].getLetter()>cardA[i].charAt(1)){
					maxNum = Integer.parseInt(cardA[i].charAt(0)+"");
					largestNumCard = i;
				}
			}

			cardsA[i] = new Card(cardA[i].charAt(0),cardA[i].charAt(1));
			cardsB[i] = new Card(cardB[i].charAt(0),cardB[i].charAt(1));
		}

		players[0].setDeck(cardsA);
		players[1].setDeck(cardsB);

		Player loser = new Player();
		Card currA = players[0].getDeck()[largestNumCard];
		Card currB;
		players[0].playCard(currA);

		int i;
		for(i=0;i<9;i++){
			currB = players[1].chooseCard(currA);
			players[0].removeCard(currA);
			if(currB.getNumber()=='0'){
				loser = players[1];
				break;
			}
			players[1].playCard(currB);
			currA = players[0].chooseCard(currB);
			players[1].removeCard(currB);
			if(currA.getNumber()=='0'){
				loser = players[0];
				break;
			}
			players[0].playCard(currA);
		}
		if(i==9){
			currB = players[1].chooseCard(currA);
			if(currB.getNumber()=='0'){
				loser = players[1];
			}else{
				loser = players[0];
			}
		}

		printLoseMessage(loser);

	}

	private static void printLoseMessage(Player player) {
		System.out.printf("Player %s loses the game!\n", player);
	}
}

class Player {
	private String name;
	private Card[] deck;

	public Card[] getDeck() {
		return deck;
	}

	public Card chooseCard(Card curr){

		Card result = new Card('0','Z');
		boolean hasCo = false;
		for(int i=0;i<10;i++){
			if(curr.getNumber()==deck[i].getNumber()){
				if(!hasCo){
				result = deck[i];
				hasCo = true;}
				else if(result.getLetter()>deck[i].getLetter()){
					result = deck[i];
				}
			}
		}
		if(!hasCo){
			for(int i=0;i<10;i++){
				if(curr.getLetter()==deck[i].getLetter()){
					if(!hasCo){
						result = deck[i];
						hasCo = true;
					}else if(result.getNumber()<deck[i].getNumber()){
						result = deck[i];
					}
				}
			}
		}
		return result;
	}

	public String getName() {
		return name;
	}

	public void setDeck(Card[] deck) {
		this.deck = deck;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void removeCard(Card card){
		for(int i=0;i<10;i++){
			if(card.getLetter()==deck[i].getLetter() && card.getNumber()==deck[i].getNumber()){
			deck[i].setNumber('0');
			deck[i].setLetter('Z');}
		}
	}

	public void playCard(Card card) {
		System.out.printf("Player %s: %s\n", name, card);
	}

	@Override
	public String toString() {
		return name;
	}
}

class Card {
	private char number; // int
	private char letter;

	Card(char number, char letter){
		this.number = number;
		this.letter = letter;
	}
	public char getLetter() {
		return letter;
	}

	public char getNumber() {
		return number;
	}

	public void setLetter(char letter) {
		this.letter = letter;
	}

	public void setNumber(char number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "" + number + letter;
	}
}
