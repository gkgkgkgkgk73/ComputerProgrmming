public class HexNumberCounter {
    public static void countHexNumbers(int n) {
        // DO NOT change the skeleton code.
        // You can add codes anywhere you want.
        int q = n;
        int m = 0;
        int[] times = new int[16];

        while(q>15){
            m=q%16;
            q= q/16;
            times[m]++;
        }
        times[q]++;

        for(int i=0;i<16;i++){
            if(times[i]>0){
                if(i<10){
                    printNumberCount((""+i).charAt(0),times[i]);
                }
                else if(i==10){
                    printNumberCount('a', times[i]);
                }else if(i==11){
                    printNumberCount('b',times[i]);
                }else if(i==12){
                    printNumberCount('c',times[i]);
                }else if(i==13){
                    printNumberCount('d',times[i]);
                }else if(i==14){
                    printNumberCount('e',times[i]);
                }else if(i==15){
                    printNumberCount('f',times[i]);
                }
            }
        }
    }

    private static void printNumberCount(char number, int count) {
        System.out.printf("%c: %d times\n", number, count);
    }
}
