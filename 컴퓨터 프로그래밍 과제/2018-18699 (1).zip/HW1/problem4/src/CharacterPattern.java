public class CharacterPattern {
    public static void searchCharPattern(String str) {
        // DO NOT change the skeleton code.
        // You can add codes anywhere you want.
        String output="";
        for(int i=1;i<str.length()-1;i++){
            if(str.charAt(i)==(str.charAt(i-1)+'A'-'a') && str.charAt(i)==(str.charAt(i+1)+('A'-'a')))
            {output+=str.charAt(i);}
            else if(str.charAt(i)==(str.charAt(i-1)+1) && str.charAt(i)==(str.charAt(i+1)-1))
            {output+=str.charAt(i);}
        }

        System.out.println(output);
    }
}
