public class FractionalNumberCalculator {
	public static void printCalculationResult(String equation) {
		// DO NOT change the skeleton code.
		// You can add codes anywhere you want.

		FractionalNumber f1 = new FractionalNumber();
		FractionalNumber f2 = new FractionalNumber();

		String[] str =equation.split("\\s");

		if(str[0].contains("/")) {
			String[] f1str = str[0].split("/");
				f1.setNumerator(Integer.parseInt(f1str[0]));
				f1.setDenominator(Integer.parseInt(f1str[1]));
		}else{
				f1.setNumerator(Integer.parseInt(str[0]));
				f1.setDenominator(1);
		}

		if(str[2].contains("/")) {
				String[] f2str = str[2].split("/");
				f2.setNumerator(Integer.parseInt(f2str[0]));
				f2.setDenominator(Integer.parseInt(f2str[1]));
		}else{
				f2.setNumerator(Integer.parseInt(str[2]));
				f2.setDenominator(1);
		}

		if(str[1].equals("+")){
			System.out.println(f1.addF(f2).toString());
		}
		else if(str[1].equals("-")){
			System.out.println(f1.subF(f2).toString());
		}
		else if(str[1].equals("*")){
			System.out.println(f1.multiF(f2).toString());
		}
		else{
			System.out.println(f1.divF(f2).toString());
		}
	}
}

class FractionalNumber {

	private int numerator;
	private int denominator;

	public int getDenominator() {
		return denominator;
	}

	public void setDenominator(int denominator) {
		this.denominator = denominator;
	}

	public int getNumerator() {
		return numerator;
	}

	public void setNumerator(int numerator) {
		this.numerator = numerator;
	}

	public void reducion(){
		int m = getNumerator();
		int n= getDenominator();
		if(m==0){
			setDenominator(1);
		}
		else{
			if(m<0){
				m=m*-1;
			}

			if(m>n){
				int i=n;
				while(i>1 && ((n%i!=0) || (m%i!=0))){
					i--;
				}

				if(i!=1){
					setDenominator(getDenominator()/i);
					setNumerator(getNumerator()/i);
				}

			}
			else {
				int i=m;
				while(i>1 && ((n%i!=0) || (m%i!=0))){
					i--;
				}

				if(i!=1){
					setDenominator(getDenominator()/i);
					setNumerator(getNumerator()/i);
				}
			}
		}
	}

	public FractionalNumber addF(FractionalNumber op){
		FractionalNumber result = new FractionalNumber();
		result.setNumerator(((op.getDenominator())*getNumerator())+((op.getNumerator())*getDenominator()));
		result.setDenominator((op.getDenominator())*getDenominator());

		result.reducion();

		return result;
	}

	public FractionalNumber subF(FractionalNumber op){
		FractionalNumber result = new FractionalNumber();
		result.setNumerator(((op.getDenominator())*getNumerator())-((op.getNumerator())*getDenominator()));
		result.setDenominator((op.getDenominator())*(getDenominator()));
		result.reducion();

		return result;
	}

	public FractionalNumber multiF(FractionalNumber op){
		FractionalNumber result = new FractionalNumber();
		result.setNumerator((op.getNumerator())*getNumerator());
		result.setDenominator((op.getDenominator())*getDenominator());
		result.reducion();

		return result;
	}

	public FractionalNumber divF(FractionalNumber op){
		FractionalNumber result = new FractionalNumber();
		result.setNumerator((op.getDenominator())*getNumerator());
		result.setDenominator((op.getNumerator())*getDenominator());
		if(result.getDenominator()<0){
				result.setDenominator(result.getDenominator()*-1);
				result.setNumerator(result.getNumerator()*-1);
		}

		result.reducion();

		return result;
	}

	@Override
	public String toString(){
		if(getDenominator()==1){
			return getNumerator()+"";
		}else{
			return getNumerator() +"/"+getDenominator();
		}
	}

}
