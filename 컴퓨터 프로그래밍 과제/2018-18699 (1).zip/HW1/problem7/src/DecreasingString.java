public class DecreasingString {
    public static void printLongestDecreasingSubstringLength(String inputString) {
        // DO NOT change the skeleton code.
        // You can add codes anywhere you want.

        int maxLength=1;
        int inputLength = inputString.length();
        int currLength = 1;

        if(inputLength==1){

        }else {
            for (int i = 1; i < inputLength; i++) {
                if((inputString.charAt(i-1)-inputString.charAt(i))>0){
                    currLength++;
                    if(currLength>maxLength){
                        maxLength=currLength;
                    }
                }else{
                    currLength=1;
                }
            }
        }

        System.out.println(maxLength);
    }
}
