public class FibonacciNumbers {
    public static void printFibonacciNumbers(int n) {
        // DO NOT change the skeleton code.
        // You can add codes anywhere you want.

        String output = fibonacciNumbers(n)+"";

        if(output.length()>5)
        {
            output = output.substring(output.length()-5,output.length());
        }

        System.out.println();
        System.out.println("sum : " + output);

    }

    public static int fibonacciNumbers(int n){

        int fn_2=0;
        int fn_1=1;
        int temp=0;
        int sum=1;

        if(n==1)
        {
            System.out.println(0);
            return 0;
        }
        else if(n==2)
        {
            System.out.println("0 1");
            return 1;
        }
        else
        {
            System.out.print("0 1");
            for(int i=2;i<n;i++){
                temp = fn_2+fn_1;
                fn_2=fn_1;
                fn_1=temp;
                System.out.print(" "+temp);
                sum+=fn_1;
            }
            return sum;
        }
    }
}
