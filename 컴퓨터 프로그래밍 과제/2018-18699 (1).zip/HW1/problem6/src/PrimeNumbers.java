public class PrimeNumbers {

    public static void printPrimeNumbers(int m, int n) {
        // DO NOT change the skeleton code.
        // You can add codes anywhere you want.
        String output = "";
        for(int i=m;i<=n;i++){
            if(checkPrimeNum(i)){
                output+=i+" ";
            }
        }
        System.out.println(output.trim());
    }

    public static boolean checkPrimeNum(int p){
        if(p==1) return false;
        else if(p==2) return true;
        else if(p%2==0){
            return false;
        }else {
            for(int i=3;i<(p/2);i++){
                if(p%i==0){
                    return false;
                }
            }
        }
        return true;
    }
}
