public class DrawingFigure {
    public static void drawFigure(int n) {
        // DO NOT change the skeleton code.
        // You can add codes anywhere you want.

        int printTarget=0;
        for(int i=1;i<n;i++){
            for(int j=0;j<2*(n-i);j++){
                System.out.print(" ");
            }
            for(int j=1;j<i;j++){
                if(j>9){
                    printTarget=j%10;
                }
                else{ printTarget = j;}
                System.out.print(printTarget+ " ");
            }
            for(int j=i;j>1;j--){
                if(j>9){
                    printTarget=j%10;
                }else{
                    printTarget=j;
                }
                System.out.print(printTarget+" ");
            }
            System.out.print(1);
            for(int j=0;j<2*(n-i);j++){
                System.out.print(" ");
            }
            System.out.println();
        }
        for(int i=n;i>=1;i--){
            for(int j=0;j<2*(n-i);j++){
                System.out.print(" ");
            }
            for(int j=1;j<i;j++){
                if(j>9){
                    printTarget=j%10;
                }
                else{ printTarget = j;}
                System.out.print(printTarget+ " ");
            }
            for(int j=i;j>1;j--){
                if(j>9){
                    printTarget=j%10;
                }else{
                    printTarget=j;
                }
                System.out.print(printTarget+" ");
            }
            System.out.print(1);
            for(int j=0;j<2*(n-i);j++){
                System.out.print(" ");
            }
            System.out.println();
        }
    }


}
