import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class FrontEnd {
    private UserInterface ui;
    private BackEnd backend;
    private User user;

    public FrontEnd(UserInterface ui, BackEnd backend) {
        this.ui = ui;
        this.backend = backend;
    }
    
    public boolean auth(String authInfo){
        // TODO sub-problem 1
        if (authInfo.equals("")) {
            return false;
        } else {
            String[] idNPW = authInfo.split("\n");

            if(idNPW[0]==null || idNPW[1]==null){
                return false;
            }else {
                if(backend.authentication(idNPW[0], idNPW[1])){
                    user = new User(idNPW[0],idNPW[1]);
                    return true;
                }else {return false;}
            }
        }
    }

    public void post(List titleContentList) {
        // TODO sub-problem 2
        if(titleContentList.size()!=3 || titleContentList.get(0)==null || titleContentList.get(1)==null|| titleContentList.get(2)==null){
            return;
        }
        backend.post(user.id, titleContentList);
    }
    
    public void recommend(int N){
        // TODO sub-problem 3
        ArrayList<Post> recommendedList = backend.recommend(user, N);
        for(Post p : recommendedList){
            ui.println(p.toString());
        }
    }

    public void search(String command) {
        List<Post> list =backend.search(user, command);
        if(list.size()<10){
            for(Post p : list){
                ui.println(p.getSummary());
            }
        }else{
            for(int i=0;i<10;i++){
                ui.println(list.get(i).getSummary());
            }
        }
    }
    
    User getUser(){
        return user;
    }
}
