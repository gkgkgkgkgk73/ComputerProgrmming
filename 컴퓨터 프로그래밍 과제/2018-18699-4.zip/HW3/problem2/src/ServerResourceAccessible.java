class ServerResourceAccessible {
    private final static String serverStorageDir = "data/";

    protected final String getServerStorageDir() {
        return serverStorageDir;
    }
}
