import java.io.*;
import java.sql.SQLIntegrityConstraintViolationException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class BackEnd extends ServerResourceAccessible{
    // Use getServerStorageDir() as a default directory
    // TODO sub-program 1 ~ 4 :
    // Create helper functions to support FrontEnd class

    int postNum=0;
    BackEnd(){
            File file = new File(getServerStorageDir());
            String[] userLists = file.list();
            for(String f: userLists){
                postNum += new File(getServerStorageDir() + f+"/post").listFiles().length;
            }
    }

    public boolean authentication(String id, String password){
        String serverPassword;
        String path = getServerStorageDir() + id + "/password.txt";
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(path));
            try {
                serverPassword = bufferedReader.readLine();
            }catch (IOException e){
                return false;
            }
        }catch(FileNotFoundException e){
            return false;
        }
        if(serverPassword==null){
            return false;
        }else{
            if(serverPassword.equals(password)){
                return true;
            }else{
                return false;
            }
        }
    }

    public boolean post(String id, List postList){
        String path = getServerStorageDir() +id+"/post";
        File file = new File(path);

        path+="/"+postNum+".txt";

        String title = (String) postList.get(0);
        String advertising = (String) postList.get(1);
        if(!(advertising.equals("yes")||advertising.equals("no"))){
            return false;
        }
        String content = (String) postList.get(2);
        Post newPost = new Post(postNum++, LocalDateTime.now(),advertising, title, content.stripTrailing());

        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(path));
            String str = newPost.getDate()+"\n"+newPost.getTitle()+"\n"+newPost.getAdvertising()+"\n\n"+newPost.getContent();
            bufferedWriter.write(str);

        }catch(IOException e){
            return false;
        }
        return false;
    }

    public ArrayList<Post> recommend(User user, int N){
        //return null means error
        String path =getServerStorageDir() + user.id + "/friend.txt";
        ArrayList<String> friendList = new ArrayList<>();
        ArrayList<Post> adPost = new ArrayList<>();
        ArrayList<Post> notAdPost = new ArrayList<>();
        ArrayList<Post> res = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(path));
            while (bufferedReader.ready()){
                friendList.add(bufferedReader.readLine());
            }
            for(String friend : friendList){
                String friPath = getServerStorageDir() +friend +"/post";
                File file = new File(friPath);
                File[] postList = file.listFiles();
                for(File tpFile : postList)
                {
                    bufferedReader = new BufferedReader(new FileReader(tpFile));
                    LocalDateTime localDateTime = Post.parseDateTimeString(bufferedReader.readLine(), Post.getFormatter());
                    String title = bufferedReader.readLine();
                    String advertising = bufferedReader.readLine();
                    bufferedReader.readLine();
                    String content="";
                    while(bufferedReader.ready()){
                        content+=bufferedReader.readLine()+"\n";
                    }
                    String tpFileName = tpFile.getName();
                    int postId = Integer.parseInt(tpFileName.substring(0,tpFileName.lastIndexOf(".")));
                    Post tpPost = new Post(postId,localDateTime,advertising,title,content);
                    if(advertising.equals("yes")){
                        adPost.add(tpPost);

                    }else if(advertising.equals("no")){
                        notAdPost.add(tpPost);
                    }
                }
            }
        }catch(IOException e){
            return null;
        }

        Collections.sort(adPost);
        if(N<=adPost.size()){
            for(int i=0;i<N;i++){
                res.add(adPost.get(i));
            }
        }else if(N> adPost.size() && N<(adPost.size()+notAdPost.size())){
            for(int i=0;i< adPost.size();i++){
                res.add(adPost.get(i));
            }
            Collections.sort(notAdPost);
            for(int i=0;i<N-adPost.size();i++){
                res.add(notAdPost.get(i));
            }
        }else{
            Collections.sort(notAdPost);
            for(int i=0;i<adPost.size();i++){
                res.add(adPost.get(i));
            }
            for(int i=0;i< notAdPost.size();i++){
                res.add(notAdPost.get(i));
            }
        }
        return res;
    }
    ArrayList<Post> allPost;
    Map<String, Integer> postIDNCnt;

    public LinkedList<Post> search(User user, String command){
        allPost = new ArrayList<>();
        String[] args = command.split(" ");
        postIDNCnt = new HashMap<>();
        Set keywords = new HashSet();
        for(int i=1;i<args.length;i++){
            keywords.add(args[i]);
        }
        String path = getServerStorageDir();

        File file = new File(path);
        String[] userList = file.list();
        for(String userName : userList){
            String userPostPath = path + userName+"/post";
            File tpFile = new File(userPostPath);
            File[] postFiles = tpFile.listFiles();
            for(File post : postFiles){
                try{
                    int count = 0;
                    boolean isStored = false;
                    BufferedReader bufferedReader = new BufferedReader(new FileReader(post));
                    String postIDTXT = post.getName().substring(0,post.getName().lastIndexOf("."));
                    String localDateTime = bufferedReader.readLine();
                    String title = bufferedReader.readLine();
                    String advertising = bufferedReader.readLine();
                    bufferedReader.readLine();
                    String content="";
                    while(bufferedReader.ready()){
                        String tpStr = bufferedReader.readLine();
                        String[] tpWords = tpStr.split("\\s");
                        for(String s : tpWords) {
                            if (keywords.contains(s)) {
                                isStored = true;
                                count++;
                            }
                        }
                        content+=tpStr+"\n";
                    }
                    if(title!=null){
                        String[] titleWords = title.split("\\s");
                        for(String s:titleWords){
                         if(keywords.contains(s)){
                              isStored=true;
                              count++;
                            }
                        }
                    }
                    if(isStored) {
                        Post newPost = new Post(Integer.parseInt(postIDTXT), Post.parseDateTimeString(localDateTime, Post.getFormatter()), advertising, title, content);
                        allPost.add(newPost);
                        postIDNCnt.put(postIDTXT,count);
                    }
                }catch(FileNotFoundException e){
                    return null;
                }catch(IOException e){
                    return null;
                }
            }
        }
        return getPostSorted(allPost,postIDNCnt);
    }

    public LinkedList<Post> getPostSorted(ArrayList<Post> target, Map<String, Integer> postIDNCnt){
        LinkedList<Post> res = new LinkedList<>();
        res.add(target.get(0));
        for(int i=1;i< target.size();i++){
            String postID = target.get(i).getId()+"";
            int newPostCnt = postIDNCnt.get(postID);
            int j=0;
            while(j<res.size() && newPostCnt<=postIDNCnt.get(res.get(j).getId()+"")){
                if(newPostCnt<postIDNCnt.get(res.get(j).getId()+"")){
                    j++;
                }else if(newPostCnt==postIDNCnt.get(res.get(j).getId()+"") && target.get(i).getContentWordNum()<res.get(j).getContentWordNum()){
                    j++;
                }else{
                    break;
                }
            }
                res.add(j,target.get(i));
        }
        return res;
    }
}
