import java.util.*;

public class AssetManage {

    private Map<Integer, Asset> idAsset = new HashMap<>();
    private Map<String, Lab> nameLab = new HashMap<>();

    public Map<Integer, Asset> getIdAsset() {return idAsset;}
    public Map<String, Lab> getNameLab() {return nameLab;}

    public boolean addAsset(int id, String item, int price, String location){
        // TODO sub-problem 1
        if(id<0){
            return false;
        }
        if(price<0 || price >100000){
            return false;
        }
        if(findAsset(id)!=null){
            return false;
        }

        Asset newAsset = new Asset(id, item, price, location);
        idAsset.put(id,newAsset);
        return true;
    }
    public boolean addLab(String labname){
        // TODO sub-problem 1
        if(labname==null || labname.equals("")){
            return false;
        }
        if(findLab(labname)!=null){
            return false;
        }
        Lab newLab = new Lab(labname);
        nameLab.put(labname, newLab);
        return true;
    }

    public Asset findAsset(int id){
        // TODO sub-problem 1
        return idAsset.get(id);
    }
    public Lab findLab(String labname){
        // TODO sub-problem 1
        return nameLab.get(labname);
    }
    public List<Asset> findAssetsWithConditions(int minprice, int maxprice, String item, String location){
        // TODO sub-problem 2
        List<Asset> res = new ArrayList<>();
        if(minprice==-1){
            if(maxprice ==-1){
                //와일드카드
                if(item.equals("All")){
                    if(location.equals("All")){
                        //price 와일드카드, item 와일드카드, location 와일드카드
                        for(Integer id : idAsset.keySet()){
                            res.add(idAsset.get(id));
                        }
                        Collections.sort(res);
                    }
                    else {
                        //price 와일드카드, item 와일드카드, location 찾기
                        for (Integer id : idAsset.keySet()) {
                            if (idAsset.get(id).getLocation().equals(location)) {
                                res.add(idAsset.get(id));
                            }
                        }
                        Collections.sort(res);
                    }
                }else{
                    if(location.equals("All")){
                        //price 와일드카드, item 찾기, location 와일드카드
                        for (Integer id : idAsset.keySet()) {
                            if (idAsset.get(id).getItem().equals(item)) {
                                res.add(idAsset.get(id));
                            }
                        }
                        Collections.sort(res);
                    }
                    else{
                        //price 와일드카드, item 찾기, location 찾기
                        for (Integer id : idAsset.keySet()) {
                            Asset tp = idAsset.get(id);
                            if (tp.getItem().equals(item) && tp.getLocation().equals(location)) {
                                res.add(tp);
                            }
                        }
                        Collections.sort(res);
                    }
                }
            }else{
                //price 와일드카드 하나만 있는 상황
                return res;
            }
        }else{
            //여기는 min, max안에 있는 것 찾아야함.
            if(item.equals("All")){
                if(location.equals("All")){
                    //price 찾기, item 와일드카드, location 와일드카드
                    for (Integer id : idAsset.keySet()) {
                        Asset tp = idAsset.get(id);
                        if (tp.getPrice()>=minprice && tp.getPrice()<=maxprice) {
                            res.add(tp);
                        }
                    }
                    Collections.sort(res);
                }
                else{
                    //price 찾기, item 와일드카드, location 찾기
                    for (Integer id : idAsset.keySet()) {
                        Asset tp = idAsset.get(id);
                        if (tp.getPrice()>=minprice && tp.getPrice()<=maxprice && tp.getLocation().equals(location)) {
                            res.add(tp);
                        }
                    }
                    Collections.sort(res);
                }
            }else{
                if(location.equals("All")){
                    //price 찾기, item 찾기, location 와일드카드
                    for (Integer id : idAsset.keySet()) {
                        Asset tp = idAsset.get(id);
                        if (tp.getPrice()>=minprice && tp.getPrice()<=maxprice && tp.getItem().equals(item)) {
                            res.add(tp);
                        }
                    }
                    Collections.sort(res);
                }
                else{
                    //price 찾기, item 찾기, location 찾기
                    for (Integer id : idAsset.keySet()) {
                        Asset tp = idAsset.get(id);
                        if (tp.getPrice()>=minprice && tp.getPrice()<=maxprice && tp.getItem().equals(item) && tp.getLocation().equals(location)) {
                            res.add(tp);
                        }
                    }
                    Collections.sort(res);
                }
            }
        }
        return res;
    }

    public boolean buyNewAsset(Lab lab, int id) {
        // TODO sub-problem 3
        if(lab==null){
            return false;
        }
        if(findAsset(id)==null){
            return false;
        }
        Asset tp = findAsset(id);
        if(tp.getOwners().size()!=0){
            return false;
        }
        if(tp.getPrice()>lab.getBalance()){
            return false;
        }
        lab.getAssetInventory().put(id,findAsset(id));
        lab.setBalance(lab.getBalance()-tp.getPrice());
        tp.getOwners().add(lab);
        return true;
    }
    public boolean tradeBtwLabs(Lab buyer, Lab seller, int id){
        // TODO sub-problem 3
        if(buyer==null || seller==null){
            return false;
        }
        if(findAsset(id)==null){
            return false;
        }
        Asset tp = findAsset(id);
        int realPrice;
        if(tp.getOwners().size()==0 || buyer.getAssetInventory().get(id)!=null || seller.getAssetInventory().get(id)==null){
            return false;
        }
        realPrice = tp.getPrice() / tp.getOwners().size();
        if(realPrice>buyer.getBalance()){
            return false;
        }

        buyer.getAssetInventory().put(id,findAsset(id));
        seller.getAssetInventory().remove(id);
        buyer.setBalance(buyer.getBalance()-realPrice);
        seller.setBalance(seller.getBalance()+realPrice);
        tp.getOwners().remove(seller);
        tp.getOwners().add(buyer);
        return true;

    }
   public boolean assetOnShare(Lab sharer, int id) {
       // TODO sub-problem 4
       if(sharer==null){
           return false;
       }

       Asset tp = findAsset(id);
       if(tp==null){
           return false;
       }
       if(tp.getOwners().size()==0 || sharer.getAssetInventory().get(id)!=null){
           return false;
       }
       int originPrice = tp.getPrice() / tp.getOwners().size();
       int newPrice = tp.getPrice() / (tp.getOwners().size()+1);

       if(newPrice>sharer.getBalance()){
           return false;
       }
       for(Lab owner : tp.getOwners()){
           owner.setBalance(owner.getBalance()+(originPrice-newPrice));
       }

       sharer.getAssetInventory().put(id,findAsset(id));
       sharer.setBalance(sharer.getBalance()-newPrice);
       tp.getOwners().add(sharer);
       return true;
   }

}
