import java.util.*;

public class Lab implements Comparator<Lab>{
    private String labname;
    private int balance;
    private Map<Integer, Asset> assetInventory;

    public Lab(String labname){
        // initial balance is 100,000 for each lab
        this.balance = 100000;
        this.labname = labname;
        assetInventory = new HashMap<>();
    }
    public int getBalance(){return balance;}

    // TODO sub-problem 1-4


    public String getLabname() {
        return labname;
    }

    public Map<Integer, Asset> getAssetInventory() {
        return assetInventory;
    }

    public void setAssetInventory(Map<Integer, Asset> assetInventory) {
        this.assetInventory = assetInventory;
    }

    public void setLabname(String labname) {
        this.labname = labname;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    @Override
    public int compare(Lab o1, Lab o2) {

        //TODO
        return -1;
    }

    @Override
    public String toString() {
        return labname;
    }
}
