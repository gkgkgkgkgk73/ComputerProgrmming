#include "header.h"
#include <algorithm>

bool compare(int i, int j){
    return i>j;
}

void MergeArrays(int* arr1, int len1, int* arr2, int len2) {
    // TODO: problem 1.3
    for(int i=0;i<len2;i++){
        arr1[i+len1] = arr2[i];
    }
    std::sort(arr1, (arr1+len1+len2), compare);
}


