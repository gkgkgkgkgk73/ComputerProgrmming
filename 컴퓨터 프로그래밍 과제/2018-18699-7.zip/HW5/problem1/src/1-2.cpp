#include <stdlib.h>
#include <vector>

int HammingDistance(int x, int y) {
    // TODO: problem 1.2
    std::vector<bool> xToHex;
    std::vector<bool> yToHex;
    int tpx = x;
    int tpy = y;
    int cnt=0;
    if(x>=y){

        while(tpx!=0){
            xToHex.push_back(tpx%2);
            tpx = tpx/2;
        }
        for(int i=0;i<xToHex.size();i++){
            yToHex.push_back(tpy%2);
            tpy = tpy/2;
        }
    }
    else if(x<y){
        while(tpy!=0){
            yToHex.push_back(tpy%2);
            tpy = tpy/2;
        }
        for(int i=0;i<yToHex.size();i++){
            xToHex.push_back(tpx%2);
            tpx = tpx/2;
        }
    }

    for(int i=0;i<xToHex.size();i++){
        if(xToHex.at(i)!=yToHex.at(i)){
            cnt++;
        }
    }

    return cnt;
}

