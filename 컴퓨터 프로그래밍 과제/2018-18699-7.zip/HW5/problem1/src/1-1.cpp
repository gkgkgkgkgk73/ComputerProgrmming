#include <string>

bool IsPalindrome(std::string s) {
    // TODO: problem 1.1
    int size = s.size();
    for(int i=0;i<(size/2);i++){
        if(s.at(i)!=s.at(size-i-1)){
            return false;
        }
    }
    return true;
}