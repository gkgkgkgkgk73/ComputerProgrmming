#include "header.h"
#include <list>

int factorial(int N){
    if(N==1 || N==0){
        return 1;
    }else{
        return N*factorial(N-1);
    }
}

int* PascalTriangle(int N) {
    // TODO: problem 1.4
    int *array = new int[N];
    for(int i=0;i<N;i++){
        int num = factorial(N-1)/(factorial(i) * factorial(N-1-i));
        array[i]=num;
    }
    return array;
}

