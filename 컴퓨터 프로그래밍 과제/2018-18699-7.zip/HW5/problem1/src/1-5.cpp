#include "header.h"
#include <cstdint>
#include <set>
#include <algorithm>

uint8_t Label = 0;
uint8_t nonAllocB = 1;
uint8_t dLabel = 50;
uint8_t white = 255;
/*
void connect(uint8_t* output_image, int width, int height,int idx){
                        *(output_image+idx) = Label;
                        if ((idx >= width + 1) && (*(output_image + idx - width - 1) == nonAllocB)) {
                            connect(output_image,width,height,idx - width - 1);
                        }
                        if ((idx >= width) && (*(output_image + idx - width) == nonAllocB)) {
                            connect(output_image,width,height,idx - width);
                        }
                        if ((idx >= width - 1) && (*(output_image + idx - width + 1) == nonAllocB)) {
                            connect(output_image,width,height,idx - width + 1);
                        }
                        if ((idx >= 1) && (*(output_image + idx - 1) == nonAllocB)) {
                            connect(output_image,width,height,idx - 1);
                        }
                        if (((idx + 1) < (height) * (width)) && (*(output_image + idx + 1) == nonAllocB)) {
                            connect(output_image,width,height,idx + 1);
                        }
                        if (((idx + width - 1) < (height) * (width)) &&
                            (*(output_image + idx + width - 1) == nonAllocB)) {
                            connect(output_image,width,height,idx + width - 1);
                        }
                        if (((idx + width) <= (height) * (width)) && (*(output_image + idx + width) == nonAllocB)) {
                            connect(output_image,width,height,idx + width);
                        }
                        if (((idx + width + 1) < (height) * (width)) &&
                            (*(output_image + idx + width + 1) == nonAllocB)) {
                            connect(output_image,width,height,idx + width + 1);
                        }
}
*/
void Labeling(const uint8_t* input_image, uint8_t* output_image, int width, int height){
    for(int i=0;i<height;i++){
        for(int j=0;j<width;j++){
            int idx = i*width+j;
            if(*(input_image+idx)==white){
                *(output_image+idx) = white;
            }else {
                *(output_image + idx) = nonAllocB;
            }
        }
    }
/* recursive
    for(int i=0;i<height;i++){
        for(int j=0;j<width;j++){
            int idx = i*width+j;
            if(*(output_image+idx)==nonAllocB){
                connect(output_image,width,height,idx);
                Label+=dLabel;
            }
        }
    }*/
//

for(int i=0;i<height;i++){
    for(int j=0;j<width;j++){
        int idx = i*width+j;
        std::set<int> tpvec;
        tpvec.clear();
        if(*(output_image+idx) == nonAllocB) {
            tpvec.insert(idx);
//            *(output_image + idx) = Label;
//            if ((idx >= width + 1) && (*(output_image + idx - width - 1) == nonAllocB)) {
//                tpvec.insert(idx - width - 1);
//            }
//            if ((idx >= width) && (*(output_image + idx - width) == nonAllocB)) {
//                tpvec.insert(idx - width);
//            }
//            if ((idx >= width - 1) && (*(output_image + idx - width + 1) == nonAllocB)) {
//                tpvec.insert(idx - width + 1);
//            }
//            if ((idx >= 1) && (*(output_image + idx - 1) == nonAllocB)) {
//                tpvec.insert(idx - 1);
//            }
//            if (((idx + 1) < (height) * (width)) && (*(output_image + idx + 1) == nonAllocB)) {
//                tpvec.insert(idx + 1);
//
//            }
//            if (((idx + width - 1) < (height) * (width)) &&
//                (*(output_image + idx + width - 1) == nonAllocB)) {
//                tpvec.insert(idx + width - 1);
//
//            }
//            if (((idx + width) <= (height) * (width)) && (*(output_image + idx + width) == nonAllocB)) {
//                tpvec.insert(idx + width);
//
//            }
//            if (((idx + width + 1) < (height) * (width)) &&
//                (*(output_image + idx + width + 1) == nonAllocB)) {
//                tpvec.insert(idx + width + 1);
//
//            }
            auto it = tpvec.begin();
            while (!tpvec.empty()) {
                it = tpvec.begin();
                const int id = *it;

                *(output_image + id) = Label;
                if ((id >= width + 1) && (*(output_image + id - width - 1) == nonAllocB)) {
                    tpvec.insert(id - width - 1);

                }
                if ((id >= width) && (*(output_image +id - width) == nonAllocB)) {
                    tpvec.insert(id - width);

                }
                if ((id >= width - 1) && (*(output_image +id - width + 1) == nonAllocB)) {
                    tpvec.insert(id - width + 1);

                }
                if ((id >= 1) && (*(output_image + id - 1) == nonAllocB)) {
                    tpvec.insert(id - 1);

                }
                if (((id+ 1) < (height) * (width)) && (*(output_image + id + 1) == nonAllocB)) {
                    tpvec.insert(id + 1);

                }
                if (((id + width - 1) < (height) * (width)) &&
                    (*(output_image + id + width - 1) == nonAllocB)) {
                    tpvec.insert(id+ width - 1);

                }
                if (((id+ width) <= (height) * (width)) && (*(output_image + id + width) == nonAllocB)) {
                    tpvec.insert(id + width);

                }
                if (((id + width + 1) < (height) * (width)) &&
                    (*(output_image + id + width + 1) == nonAllocB)) {
                    tpvec.insert(id + width + 1);
                }
                tpvec.erase(it);
            }

            Label+=dLabel;
        }
    }
}
//
}

