#include "Delta.h"
#include <vector>

using namespace std;

Delta::Delta() : delta_unit_(NULL), num_data_(0), data_bit_width_(0), delta_bit_width_(0) {}

Delta::~Delta() {
    if(delta_unit_){
        delete[] delta_unit_;
    }
}

void Delta::Print(std::ostream& os) const{
    os << data_bit_width_ << " ";
    os << delta_bit_width_ << " ";
    os << num_data_ << " ";
    os << base_data_ << " ";
    for(int i=0; i<num_data_-1; i++){
        os << delta_unit_[i];
    }
    os<<endl;
}

std::ostream& operator<<(std::ostream& os, const DeltaUnit& du){
    // TODO: problem 2.3

    return os<<"(dt "<<du.delta<<")";
}

void Delta::Encode(const char* file_name){
    // TODO: problem 2.4

    std::fstream fin(file_name);
    int tpInt;
    fin>>tpInt;
    data_bit_width_ = tpInt;
    fin>>tpInt;
    num_data_ = tpInt;
    std::vector<int> dataSet;
    dataSet.clear();
    int lastNum=-1;
    int maxDelta = 0;
    fin>>tpInt;
    lastNum = tpInt;
    base_data_ = tpInt;
    for(int i=0;i<num_data_;i++){
        fin>>tpInt;
            int d = tpInt - lastNum;
            dataSet.push_back(d);
            if(abs(d)>maxDelta){
                maxDelta = abs(d);
            }
            lastNum = tpInt;
    }
    fin.close();
    delta_bit_width_ = ceil(log2(maxDelta+1))+1;
    delta_unit_ = new DeltaUnit[num_data_];
    for(int i=0;i<num_data_;i++){
        delta_unit_[i].delta = dataSet.at(i);
    }
}

double Delta::Evaluate(const char* file_name) {
    // TODO: problem 2.5
    int inputSize = (num_data_+2)*data_bit_width_;
    int DeltaEncodeSize= data_bit_width_+(num_data_-1)*delta_bit_width_+data_bit_width_*3;
    double res = ((double)(inputSize*100/DeltaEncodeSize)/100);
    return res;
}
