#include "RunLength.h"
#include <vector>
#include <algorithm>
using namespace std;

RunLength::RunLength() : run_length_unit_(NULL), num_data_(0), data_bit_width_(0), length_bit_width_(0) {}
RunLength::~RunLength() {
    if(run_length_unit_){
        delete[] run_length_unit_;
    }
}
void RunLength::set_data_bit_width(int data_bit_width) {
    length_bit_width_ = data_bit_width;
}

void RunLength::Print(std::ostream& os) const{
    os << data_bit_width_ << " ";
    os << length_bit_width_ << " ";
    os << num_data_ << " ";
    for(int i=0; i<num_data_; i++){
        os<<run_length_unit_[i];
    }
    os<<endl;
}


std::ostream& operator<<(std::ostream& os, const RunLengthUnit& rlu){
    // TODO: problem 2.1

    return os<<"("<<rlu.data<<" "<<rlu.length<<")";
}

void RunLength::Encode(const char* file_name){
    // TODO: problem 2.2
    std::fstream fin(file_name);
    int tpInt;
    fin>>tpInt;
    data_bit_width_ = tpInt;
    fin>>tpInt;
    num_data_ = tpInt;
    std::vector<pair<int,int>> dataSet;
    dataSet.clear();
    int dataSetNum=0;
    int lastNum=-1;
    int cnt=0;
    for(int i=0;i<num_data_;i++){
        fin>>tpInt;
        if(tpInt==lastNum && cnt<pow(2,length_bit_width_)){
            lastNum = tpInt;
            cnt++;
        }else if(tpInt == lastNum && cnt == pow(2,length_bit_width_)){
            dataSet.push_back(pair<int, int> (lastNum,++cnt));
            dataSetNum++;
            cnt = 1;
        }
        else{
            if(lastNum!=-1){
            dataSet.push_back(pair<int, int>(lastNum, cnt));
            }
            dataSetNum++;
            lastNum = tpInt;
            cnt =1;
        }
    }
    dataSet.push_back(pair<int, int>(lastNum, cnt));
    fin.close();

    run_length_unit_ = new RunLengthUnit[dataSetNum];
    num_data_ = dataSetNum;
    for(int i=0;i<dataSetNum;i++){
        run_length_unit_[i].data = dataSet.at(i).first;
        run_length_unit_[i].length = dataSet.at(i).second;
    }
}

double RunLength::Evaluate(const char* file_name) {
    // TODO: problem 2.5
    int oriDataNum=0;
    for(int i=0;i<num_data_;i++){
        oriDataNum+=run_length_unit_[i].length;
    }
    int inputSize = data_bit_width_*(2+oriDataNum);
    int RLEncodeSize = num_data_*(data_bit_width_+length_bit_width_)+length_bit_width_*data_bit_width_;
    double res = ((double)(inputSize*100/RLEncodeSize))/100;
    return res;
}
