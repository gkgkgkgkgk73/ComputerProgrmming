package bank;

import bank.event.*;
import security.method.Deposit;

class BankAccount {
    // Do NOT change access modifier
    private Event[] events = new Event[maxEvents];
    final static int maxEvents = 100;
    private String id;
    private String password;
    private int balance;
    private String question = null;
    private String answer = null;

    private int eventIndex = 0;

    BankAccount(String id, String password, int balance) {

        this.id = id;
        this.password = password;
        this.balance = balance;

    }

    public int getEventIndex() {
        return eventIndex;
    }

    public Event[] getEvents() {
        return events;
    }

    public int getBalance() {
        return balance;
    }


    BankAccount(String id, String password, int balance, String question, String answer) {
        //TODO: Problem 1.3
        this.id = id;
        this.password = password;
        this.balance = balance;
        this.question = question;
        this.answer = answer;
    }


    boolean authenticate(String password) {

        if (this.password.equals(password)) {
            return true;
        } else {
            return false;
        }
    }

    void deposit(int amount, int transId) {

        DepositEvent dEvent = new DepositEvent(amount, transId);
        events[eventIndex++] = dEvent;
        balance += amount;

    }

    boolean withdraw(int amount, int transId) {

        if (amount <= this.balance) {
            balance -= amount;
            WithdrawEvent wEvent = new WithdrawEvent(amount, transId);
            events[eventIndex++] = wEvent;
            return true;
        } else {
            return false;
        }
    }

    void receive(int amount, int transId) {

        balance += amount;
        ReceiveEvent rEvent = new ReceiveEvent(amount, transId);
        events[eventIndex++] = rEvent;

    }

    boolean send(int amount, int transId) {

        if (balance >= amount) {
            balance -= amount;
            SendEvent sEvent = new SendEvent(amount, transId);
            events[eventIndex++] = sEvent;
            return true;
        } else {
            return false;
        }

    }


    boolean secondaryAuthenticate(String questionAnswer) {
        //TODO: Problem 1.3
        String[] qnA = questionAnswer.split(",");
        String q = qnA[0];
        String a = qnA[1];
        if(this.question==null || this.answer==null){
            return false;
        }else if(this.question.equals(q) && this.answer.equals(a)){
            return true;
        }else{
            return false;
        }
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getQuestion() {
        return question;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getAnswer() {
        return answer;
    }

}

