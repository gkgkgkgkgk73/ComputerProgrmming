package bank;

import bank.event.*;
import security.*;
import security.key.*;
import security.method.Withdraw;

public class Bank {
    private int numAccounts = 0;
    final static int maxAccounts = 100;
    private BankAccount[] accounts = new BankAccount[maxAccounts];
    private String[] ids = new String[maxAccounts];

    public void createAccount(String id, String password) {
        //TODO: Problem 1.1
        int initBalance = 0;
        if(find(id)==null) {
            BankAccount bankAccount = new BankAccount(id, password, initBalance);
            accounts[numAccounts] = bankAccount;
            ids[numAccounts++] = id;
        }
    }

    public void createAccount(String id, String password, int initBalance) {
        //TODO: Problem 1.1
        if(find(id)==null) {
            BankAccount bankAccount = new BankAccount(id, password, initBalance);
            accounts[numAccounts] = bankAccount;
            ids[numAccounts++] = id;
        }
    }

    public boolean deposit(String id, String password, int amount, int transId) {
        //TODO: Problem 1.1
        BankAccount bankAccount = find(id);
        if(bankAccount==null)
        {
            return false;
        }
        else if(!bankAccount.authenticate(password))
        {
            return false;
        }
        else
        {
            bankAccount.deposit(amount, transId);
            return true;
        }
    }

    public boolean withdraw(String id, String password, int amount, int transId) {
        //TODO: Problem 1.1
        BankAccount bankAccount = find(id);
        if(bankAccount==null)
        {
            return false;
        }
        else if(!bankAccount.authenticate(password))
        {
            return false;
        }
        else
        {
            return bankAccount.withdraw(amount, transId);
        }
    }

    public boolean transfer(String sourceId, String password, String targetId, int amount, int transId) {
        //TODO: Problem 1.1
        BankAccount bankAccount = find(sourceId);
        BankAccount targetAccount = find(targetId);
        if(bankAccount==null || targetAccount==null)
        {
            return false;
        }
        else if(!bankAccount.authenticate(password))
        {
            return false;
        }
        else
        {
            if(bankAccount.send(amount, transId))
            {
                targetAccount.receive(amount, transId);
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public Event[] getEvents(String id, String password) {
        //TODO: Problem 1.1
        BankAccount bankAccount = find(id);
        if(bankAccount==null){
            return null;
        }else if(!bankAccount.authenticate(password)){
            return null;
        }else{
            int eventNum = bankAccount.getEventIndex();
            if(eventNum==0){
                return null;
            }else {
                Event[] res = new Event[eventNum];
                Event[] accountEvents = bankAccount.getEvents();
                for(int i=0;i<eventNum;i++){
                    res[i] = accountEvents[i];
                }
                return res;
            }
        }
    }

    public int getBalance(String id, String password) {
        //TODO: Problem 1.1
        BankAccount bankAccount = find(id);
        if(bankAccount==null || !bankAccount.authenticate(password)){
            return -1;
        }else{
            return bankAccount.getBalance();
        }
    }

    private static String randomUniqueStringGen(){
        return Encryptor.randomUniqueStringGen();
    }

    private BankAccount find(String id) {
        for (int i = 0; i < numAccounts; i++) {
            if(ids[i].equals(id)){return accounts[i];}
        }
        return null;
    }


    private BankSecretKey secretKey;
    public BankPublicKey getPublicKey(){
        BankKeyPair keypair = Encryptor.publicKeyGen(); // generates two keys : BankPublicKey, BankSecretKey
        secretKey = keypair.deckey; // stores BankSecretKey internally
        return keypair.enckey;
    }

    int maxHandshakes = 10000;
    int numSymmetrickeys = 0;
    BankSymmetricKey[] bankSymmetricKeys = new BankSymmetricKey[maxHandshakes];
    String[] AppIds = new String[maxHandshakes];

    public int getAppIdIndex(String AppId){
        for(int i=0; i<numSymmetrickeys; i++){
            if(AppIds[i].equals(AppId)){
                return i;
            }
        }
        return -1;
    }

    public void fetchSymKey(Encrypted<BankSymmetricKey> encryptedKey, String AppId){
        //TODO: Problem 1.2
        int idx;
        if(encryptedKey==null){
            return;
        }
        BankSymmetricKey tpKey = encryptedKey.decrypt(secretKey);
        if(tpKey==null){return;}
        if((idx = getAppIdIndex(AppId))!=-1){
            bankSymmetricKeys[idx] = tpKey;
        }
        else {
            bankSymmetricKeys[numSymmetrickeys] = tpKey;
            AppIds[numSymmetrickeys++] = AppId;
        }
    }

    public Encrypted<Boolean> processRequest(Encrypted<Message> messageEnc, String AppId) {
        //TODO: Problem 1.2
        int idx = getAppIdIndex(AppId);
        if(idx==-1){
            return null;
        }else if(messageEnc==null){
            return null;
        }
        else{
            Message tp = messageEnc.decrypt(bankSymmetricKeys[idx]);
            if(tp==null){
                return null;
            }
            String requestType = tp.getRequestType();
            String mId = tp.getId();
            String mPassword = tp.getPassword();
            int mAmount = tp.getAmount();
            int mTransId = tp.getTransId();
            if (requestType.equals("deposit")){
                Boolean resBool = deposit(mId,mPassword,mAmount,mTransId);
                Encrypted<Boolean> res = new Encrypted<>(resBool,bankSymmetricKeys[idx]);
                return res;
            }else if(requestType.equals("withdraw")){
                Boolean resBool = withdraw(mId,mPassword,mAmount,mTransId);
                Encrypted<Boolean> res = new Encrypted<>(resBool,bankSymmetricKeys[idx]);
                return res;
            }
            else if(requestType.equals("compensate")){
                String mQnA = tp.getQnA();
                int[] mTransIdList = tp.getTransIdList();
                Boolean resBool = compensate(mId,mPassword,mQnA,mTransIdList);
                Encrypted<Boolean> res  = new Encrypted<>(resBool,bankSymmetricKeys[idx]);
                return res;
            }
            else{
                return null;
            }
        }
    }

    public void createAccount(String id, String password, int initBalance, String question, String answer) {
        //TODO: Problem 1.3
        if(!(question.equals("BestProfessor") || question.equals("BestTA"))){
            return;
        }else if(question.contains(" ") || answer.contains(" ")){
            return;
        }else{
            for(int i=0;i<answer.length();i++){
                if(!((answer.charAt(i)>='a' && answer.charAt(i)<='z')||(answer.charAt(i)>='A'&&answer.charAt(i)<='Z')))
                {
                    return;
                }
            }
        }
        BankAccount bankAccount = find(id);
        if(bankAccount==null){
            //make new account
            bankAccount = new BankAccount(id,password,initBalance,question,answer);
            accounts[numAccounts] = bankAccount;
            ids[numAccounts++] = id;
        }else{
            if(bankAccount.authenticate(password)){
                //succeed auth
                bankAccount.setQuestion(question);
                bankAccount.setAnswer(answer);
            }else{
                //fail auth
                return;
            }
        }
    }

    public boolean compensate(String id, String password, String questionAnswer, int[] transIdList){
        //TODO: Problem 1.3
        BankAccount bankAccount = find(id);

        if(!bankAccount.authenticate(password)){
            return false;
        }else if(!bankAccount.secondaryAuthenticate(questionAnswer)){
            return false;
        }else{
            Event[] events = getEvents(id,password);
            int robbedSum=0;
            for(int i=0;i<events.length;i++){
                for(int j=0;j<transIdList.length;j++){
                    if(events[i].getTransId()==transIdList[j]){
                        if(events[i] instanceof WithdrawEvent){
                            robbedSum+=events[i].getAmount();
                        }
                    }
                }
            }
            deposit(id,password,robbedSum,0);
            return true;
        }
    }
}
