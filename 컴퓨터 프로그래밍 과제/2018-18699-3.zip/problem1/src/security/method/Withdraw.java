package security.method;

public class Withdraw extends RequestMethod{
	//don't modify or use this class
	//We will replace this class for grading
}
