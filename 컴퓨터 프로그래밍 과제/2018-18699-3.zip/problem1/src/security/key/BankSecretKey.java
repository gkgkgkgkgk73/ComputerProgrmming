package security.key;

public class BankSecretKey extends BankKey {
    public BankSecretKey(String value) {
        super(value);
    }
}
