package security.key;

public abstract class BankKey{
    public String value;
    public BankKey(String value){
        this.value = value;
    }
}
