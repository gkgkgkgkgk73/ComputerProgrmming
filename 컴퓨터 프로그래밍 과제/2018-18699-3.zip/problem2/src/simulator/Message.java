package relay.simulator;

import relay.map.Map;
import relay.player.Player;

public class Message {
    private Player currentHuman;
    private Player currentAnimal;
    private Map map;
    private int time;


    public Message(Player human, Player animal, Map map, int time) {
        this.currentHuman = human;
        this.currentAnimal = animal;
        this.map = map;
        this.time = time;
    }

    public double getDistance() {
        //TODO: Problem 2.1
        double distance = currentAnimal.getPosition() - currentHuman.getPosition();
        if (distance > 0) {
            return distance;
        } else {
            return -1 * distance;
        }
    }

    public Map getMap() {
        return map;
    }

    String res=null;
    boolean isModified = false;
    @Override
    public String toString() {
        //TODO: Problem 2.1
        if(isModified){
            return res;
        }else{
        boolean isHumanGivingUp = currentHuman.getThrowUp();
        boolean isAnimalGivingUp = currentAnimal.getThrowUp();
        double currHumanPosition = currentHuman.getPosition();
        double currAnimalPosition = currentAnimal.getPosition();

        if(isHumanGivingUp && isAnimalGivingUp){
            res = time +": [FINISH] Both teams throw up the race";
        }else{
            if(currAnimalPosition == 0 && currHumanPosition ==0){
                res  = time + ": [READY] Human team : " + currentHuman.toCustomString()+" / Animal team : "+ currentAnimal.toCustomString() +" are at 0";
            }
            else if(currHumanPosition == map.getMapEnd() && currAnimalPosition != map.getMapEnd()){
                res = time + ": [FINISH] Human team wins";
            }else if(currHumanPosition != map.getMapEnd() && currAnimalPosition == map.getMapEnd()){
                res = time + ": [FINISH] Animal team wins";
            }else if(currHumanPosition == map.getMapEnd() && currAnimalPosition == map.getMapEnd()){
                res = time + ": [FINISH] Both teams reach the goal at the same time";
            }else{
                res = time + ": [RUNNING] Human team : "+currentHuman.toCustomString() +" is at " + String.format("%.1f",currHumanPosition) +" / Animal team : "+currentAnimal.toCustomString() + " is at "+String.format("%.1f",currAnimalPosition);
            }
        }
        isModified=true;
        return res;
    }
    }
}
