package relay.simulator;

import relay.player.Player;
import relay.map.Map;
import relay.player.animal.Animal;
import relay.player.human.Human;

import java.util.ArrayList;

public class Simulator {
    final static int maxTeamPlayerNum=4;
    private final ArrayList<Player> humanPlayers;
    private final ArrayList<Player> animalPlayers;
    private final Map map;
    private boolean raceFinish = false; // For testbench
    public String[] raceLogForEval = new String[200]; // For evaluation, don't remove

    private Player currentHuman;
    private Player currentAnimal;

    public Simulator(ArrayList<Player> humanPlayers, ArrayList<Player> animalPlayers, Map map){
        //TODO: Problem 2.3
	    //for ascending order of position
        java.util.Collections.sort(humanPlayers);
        java.util.Collections.sort(animalPlayers);

        this.map = map;
        this.humanPlayers = humanPlayers;
        this.animalPlayers = animalPlayers;
        for(int i=0;i<humanPlayers.size();i++){
            humanPlayers.get(i).setPlayerNum(i+1);
            if(i==0){
                currentHuman = humanPlayers.get(i);
                humanPlayers.get(i).setCurrentPlayer(true);
            }else{
                humanPlayers.get(i-1).setNextPlayerPosition(humanPlayers.get(i).getPosition());
                humanPlayers.get(i).setCurrentPlayer(false);
            }
        }
        humanPlayers.get(humanPlayers.size()-1).setNextPlayerPosition(map.getMapEnd());

        for(int i=0;i<animalPlayers.size();i++){
            animalPlayers.get(i).setPlayerNum(i+1);
            if(i==0){
                currentAnimal = animalPlayers.get(i);
                animalPlayers.get(i).setCurrentPlayer(true);
            }else{
                animalPlayers.get(i-1).setNextPlayerPosition(animalPlayers.get(i).getPosition());
                animalPlayers.get(i).setCurrentPlayer(false);
            }
        }
        animalPlayers.get(animalPlayers.size()-1).setNextPlayerPosition(map.getMapEnd());

    }


    public void snapshot() {
        //TODO: Problem 2.3
        Player hPlayer;
        Player aPlayer;
        if((currentHuman.getPosition() == currentHuman.getNextPlayerPosition()) && (currentHuman.getNextPlayerPosition() !=map.getMapEnd())){
            currentHuman.passBaton((hPlayer = humanPlayers.get(humanPlayers.indexOf(currentHuman)+1)));
            currentHuman = hPlayer;
        }
        if((currentAnimal.getPosition() == currentAnimal.getNextPlayerPosition())&&(currentAnimal.getNextPlayerPosition()!=map.getMapEnd())){
            currentAnimal.passBaton((aPlayer = animalPlayers.get(animalPlayers.indexOf(currentAnimal)+1)));
            currentAnimal = aPlayer;
        }
    }


    public Message talk(int time) {
        Message msg = new Message(currentHuman, currentAnimal, map, time);
        raceLogForEval[time]=msg.toString();
        return msg;
    }

    public boolean getRaceFinish(){return raceFinish;}


     public void simulate() {
        //TODO: Problem 2.3
         String str = "[ERROR] Team building error";
         if(humanPlayers.size()>maxTeamPlayerNum || animalPlayers.size()>maxTeamPlayerNum){
            raceLogForEval[0] = str;
            raceFinish = true;
            return;
         }
         for(int i=0;i<animalPlayers.size();i++){
             if (!(animalPlayers.get(i) instanceof Animal)){
                 raceLogForEval[0] = str;
                 raceFinish = true;
                 return;
             }
         }
         for(int i=0;i<humanPlayers.size();i++){
             if(!(humanPlayers.get(i) instanceof Human)){
                 raceLogForEval[0] = str;
                 raceFinish =true;
                 return;
             }
         }
         if(currentHuman.getPosition()!=0 || currentAnimal.getPosition()!=0){
             raceLogForEval[0] = str;
             raceFinish = true;
             return;
         }

         int time =0;
         Message msg = talk(time);
         raceLogForEval[time] = msg.toString();
         do{
             time++;
             currentHuman.hear(msg);
            currentHuman.move();
            currentAnimal.move();
            snapshot();
            msg = talk(time);
            raceLogForEval[time] = msg.toString();

         }while(!((currentAnimal.getThrowUp() && currentHuman.getThrowUp())||currentAnimal.getPosition()==map.getMapEnd()||currentHuman.getPosition()==map.getMapEnd()));
         raceFinish=true;
    }

}
