package relay.player;

import relay.map.Map;

public class Eyesight {
    private static final double range = 3;
    private double nextPlayerPosition;	
    private Map map;

    public Eyesight(Map map){
            this.map = map;
        }
	public void setNextPlayerPosition(double position){
        nextPlayerPosition=position;
    }
    public double getRange(){return range;}

    public double getDistanceToBoundary(double playerPosition){
        //TODO: Problem 2.1
        double distance;
        boolean isWater = map.getOnWater(playerPosition);
        if(isWater){
            distance = map.getWaterEnd() - playerPosition;
            return distance>3 ? 3 : distance;
        }else{
            if(map.getWaterEnd()<=playerPosition){
                distance = map.getMapEnd() -playerPosition;
                return distance>3 ? 3 : distance;
            }else{
                distance = map.getWaterStart() - playerPosition;
                return distance>3 ? 3: distance;
            }
        }
    }

    public double getDistanceToNextPlayer(double playerPosition){
        //TODO: Problem 2.1
        double distance = nextPlayerPosition - playerPosition;
        return distance >3 ? 3 : distance;
    }

}
