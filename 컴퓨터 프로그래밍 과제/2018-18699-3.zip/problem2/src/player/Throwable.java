package relay.player;

import relay.map.Map;

public interface Throwable {
     boolean throwUp(double position, Map map);
}
