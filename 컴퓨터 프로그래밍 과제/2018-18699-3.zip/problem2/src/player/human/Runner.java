package relay.player.human;

import relay.player.Player;
import relay.player.Throwable;
import relay.map.Map;
import relay.simulator.Message;

public class Runner extends Human implements Throwable{

    public Runner(Map map){this(0, map);}
    public Runner(double position, Map map) {
        super(position, 2, map);
    }

    @Override
    public void hear(Message message) {
        //TODO: Problem 2.2
        if((!message.getMap().getOnWater(getPosition())) && message.getDistance()<2 && (message.getMap().getMapEnd()<=getEyesight().getRange() || getEyesight().getDistanceToNextPlayer(getPosition())<getEyesight().getRange())){
            setVelocity(2.5);
        }else if(message.getMap().getOnWater(getPosition())){
            setVelocity(1);
        }else{
            setVelocity(2);
        }
    }

    @Override
    public void move() {
        //TODO: Problem 2.2
        if(getMap().getOnWater(getPosition())){
            if(getEyesight().getDistanceToNextPlayer(getPosition())<=getEyesight().getRange() || getEyesight().getDistanceToBoundary(getPosition())<=getEyesight().getRange()){
                setPosition(getPosition()+getMovableDistance(1));
            }else{
                throwUp(getPosition(),getMap());
            }
        }else{
            setPosition(getPosition()+getMovableDistance(getVelocity()));
        }
    }

    @Override
    public String toCustomString() {
        //TODO: Problem 2.2
        String res ="";
        if(getPlayerNum()==1){
                res = getPlayerNum()+"st human player, runner";
        }
        else if(getPlayerNum()==2){
                res = getPlayerNum()+"nd human player, runner";
        }
        else if(getPlayerNum()==3){
                res = getPlayerNum()+"rd human player, runner";
        }else{
            res = getPlayerNum()+"th human player, runner";
        }
        return res;
    }

    public boolean throwUp(double position, Map map){
        //TODO: Problem 2.2
        if(map.getWaterStart() == position){
            if(getEyesight().getDistanceToBoundary(position)<getEyesight().getRange() || getEyesight().getDistanceToNextPlayer(position)<getEyesight().getRange()){
                return false;
            }else{
                return true;
            }
        }

        return false;
    }
    @Override
    public boolean getThrowUp(){
        //TODO: Problem 2.2
        return throwUp(getPosition(),getMap());
    }

    @Override
    public int compareTo(Player o) {
        //TODO
        if(o.getPosition()<getPosition()){
            return 1;
        }else if(o.getPosition()==getPosition()){
            return 0;
        }else{
            return -1;
        }
    }
}

