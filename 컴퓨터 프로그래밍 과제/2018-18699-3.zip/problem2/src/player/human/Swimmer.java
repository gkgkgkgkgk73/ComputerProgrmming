package relay.player.human;

import relay.player.Player;
import relay.player.Swimmable;
import relay.map.Map;
import relay.simulator.Message;

public class Swimmer extends Human implements Swimmable {
    private double swimSpeed;

    public Swimmer(Map map){this(0, map);}
    public Swimmer(double position, Map map) {
        super(position,1.5,map);
        this.swimSpeed= 2;
    }

    static boolean hasWarmUp =false;

    @Override
    public void hear(Message message) {
        //TODO: Problem 2.2
        if((!message.getMap().getOnWater(getPosition())) && message.getDistance()<2){
            if(message.getMap().getMapEnd()<=getEyesight().getRange() || getEyesight().getDistanceToNextPlayer(getPosition())<getEyesight().getRange()){
                setVelocity(2);
            }else{
                setVelocity(1.5);
            }
        }
    }

    @Override
    public void move() {
        //TODO: Problem 2.2
		//Use swim method.
        if(!getMap().getOnWater(getPosition())){
            setPosition(getPosition()+getMovableDistance(getVelocity()));
        }else{
		    swim();
        }
    }
    public void swim(){
        //TODO: Problem 2.2
        if(!hasWarmUp){
            hasWarmUp =true;
        }else{
            setPosition(getPosition()+getMovableDistance(swimSpeed));
        }
    }

    @Override
    public String toCustomString() {
        //TODO: Problem 2.2
        String res ="";
        if(getPlayerNum()==1){
            res = getPlayerNum()+"st human player, swimmer";
        }
        else if(getPlayerNum()==2){
            res = getPlayerNum()+"nd human player, swimmer";
        }
        else if(getPlayerNum()==3){
            res = getPlayerNum()+"rd human player, swimmer";
        }else{
            res = getPlayerNum()+"th human player, swimmer";
        }
        return res;
    }

    @Override
    public boolean getThrowUp(){return false;}

    @Override
    public int compareTo(Player o) {
        //TODO
        if(o.getPosition()<getPosition()){
            return 1;
        }else if(o.getPosition()==getPosition()){
            return 0;
        }else{
            return -1;
        }
    }
}
