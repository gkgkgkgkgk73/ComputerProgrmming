package relay.player.animal;

import relay.player.Player;
import relay.player.Throwable;
import relay.map.Map;

public class Rabbit extends Animal implements Throwable {

    public Rabbit(Map map){this(0, map);}
    public Rabbit(double position, Map map) {
        super(position,3,map);
    }

    @Override
    public void move() {
        //TODO: Problem 2.2
        if(getPosition()==getMap().getWaterStart()){
                throwUp(getPosition(),getMap());
        }else{
            setPosition(getPosition()+getMovableDistance(getVelocity()));
        }
    }

    @Override
    public String toCustomString() {
        //TODO: Problem 2.2
        String res ="";
        if(getPlayerNum()==1){
            res = getPlayerNum()+"st animal player, rabbit";
        }
        else if(getPlayerNum()==2){
            res = getPlayerNum()+"nd animal player, rabbit";
        }
        else if(getPlayerNum()==3){
            res = getPlayerNum()+"rd animal player, rabbit";
        }else{
            res = getPlayerNum()+"th animal player, rabbit";
        }
        return res;
    }

    public boolean throwUp(double position, Map map){
        //TODO: Problem 2.2
        if(position==getMap().getWaterStart()){
            return true;
        }else{
            return false;
        }
    }
    @Override
    public boolean getThrowUp(){
        //TODO: Problem 2.2
        return throwUp(getPosition(),getMap());
    }

    @Override
    public int compareTo(Player o) {
        if(o.getPosition()<getPosition()){
            return 1;
        }else if(o.getPosition()==getPosition()){
            return 0;
        }else{
            return -1;
        }
    }
}
